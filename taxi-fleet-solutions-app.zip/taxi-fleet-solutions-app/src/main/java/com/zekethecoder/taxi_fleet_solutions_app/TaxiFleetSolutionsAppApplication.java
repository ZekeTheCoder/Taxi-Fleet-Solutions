package com.zekethecoder.taxi_fleet_solutions_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxiFleetSolutionsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaxiFleetSolutionsAppApplication.class, args);
	}

}
